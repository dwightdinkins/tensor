MathGR
======

MathGR is a package for GR calculation, written in Mathematica. 

The manual of the package is available at http://arxiv.org/abs/1306.1295
